# procedures to create the translation
spade = 'ofspade'
heart = 'ofheart'
club = 'ofclub'
diamond = 'ofdiamond'
cardsList = ['ace', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'jack', 'queen', 'king']
inputer = []
for spader in cardsList:
    inputer.append(f'{spader}{spade}')
for hearter in cardsList:
    inputer.append(f'{hearter}{heart}')
for cluber in cardsList:
    inputer.append(f'{cluber}{club}')
for diamonder in cardsList:
    inputer.append(f'{diamonder}{diamond}')
rawer = ['01,', '02,', '03,', '04,', '05,', '06,', '07,', '08,', '09,']
for number in range(10, 53):
    rawer.append(f'{number},')
# creating the translation
translation = {}
value = 0
for stuff in inputer:
    value += 1
    translation.update({stuff: value})
value = 0
for stuffs in rawer:
    value += 1
    translation.update({stuffs: value})
# freeing up the memory
rawer.clear()
cardsList.clear()
inputer.clear()
spade, heart, club, diamond = str(), str(), str(), str()


def process():
    global translation, input1, input2, input3, input4, input5
    inputList = [translation[input1], translation[input2], translation[input3], translation[input4], translation[input5]]
    inputList.sort()
    with open('rawData.txt', 'r') as rawData:
        for data in rawData:
            dataList = [translation[data[0:3]], translation[data[3:6]], translation[data[6:9]], translation[data[9:12]], translation[data[12:15]]]
            dataList.sort()
            if inputList == dataList:
                spadeStart = data.index('(') + 1
                spadeEnd = data.index('/')
                heartStart = data.index('/') + 1
                heartEnd = data.index('.')
                clubStart = data.index('.') + 1
                clubEnd = data.index('-')
                diamondStart = data.index('-') + 1
                diamondEnd = data.index(')')
                indicators = [int(data[spadeStart:spadeEnd]), int(data[heartStart:heartEnd]), int(data[clubStart:clubEnd]), int(data[diamondStart:diamondEnd])]
                percentage = [x / 10 for x in indicators]
                return f'>> {input1}, {input2}, {input3}, {input4}, {input5} = ({percentage[0]}% spade, {percentage[1]}% heart, {percentage[2]}% club, {percentage[3]}% diamond)'


while True:
    input1 = input('type in your cards one by one:\ncard1: ').replace(' ', '')
    input2 = input('card2: ').replace(' ', '')
    input3 = input('card3: ').replace(' ', '')
    input4 = input('card4: ').replace(' ', '')
    input5 = input('card5: ').replace(' ', '')
    try:
        print(process())
    except KeyError:
        print('Invalid card(s)\nPlease try again!\n')
        continue
    finalQuestion = str(input('Another Round? Y/N\n'))
    finalQuestion = finalQuestion.lower()
    if finalQuestion == 'y':
        continue
    elif finalQuestion == 'n':
        print('Good Luck!')
        break
    else:
        print('Invalid Answer, Goodbye!')
        break
